#0.1 map function in count laters 
Name=["Naveen","Nani","Divya","Mounika"]
for i in Name:
   print(len(i))
result=list(map(len,Name))
print(result)


0.#dict 
d={1:10,2:20,3:30,4:40}
result=list(d.keys())
print(result)
result=list(d.values())
print(result)
print(d)

1.#dict change the key and value
emp={"empid":101,"empjob":"hr"}
emp["empid"]=100
print(emp)
emp = {"empid": 101, "empjob": "hr"}
emp["empn"] = emp.pop("empid")
print(emp)
#2.Difference Between List and Tuple?


#3.What is Decorator Explain With Example ? 
def my_decorator(func):
    def wrapper():
        print("Before the function is called.")
        func()
        print("After the function is called.")
    return wrapper

@my_decorator
def my_function():
    print("Hello, world!")
my_function()


#4.Difference Between List and Dict Comprehension?
l = [i for i in range(10) if i%2]
print(l)

d={i:i*i for i in range(1,10)}
print (d)

#5.Difference Between Generators And Iterators?
    #Generators are iterators which can execute only once.d 
    #Generator uses “yield” keyword.
    #Generators are mostly used in loops to generate an iterator 
    #by returning all the values in the loop without affecting the iteration of the loop.
    #Every generator is an iterator.
   

def sqr(n):
 for i in range(1, n+1):
    yield i*i 
a = sqr(3) 
print(next(a))
print(next(a))
print(next(a))

#Iterators
iter = iter(['A', 'B', 'C'])
print(next(iter))
print(next(iter))
print(next(iter))

#6.What are in-built Data Types in Python OR Explain Mutable and Immutable Data Types?
#7.Explain Ternary Operator in Python?
x = 10
y = 20
max = x if x > y else y
print(max)

#7.What is Inheritance In Python?
class A: 
  def display(self): 
    print("A Display") 
class B(A): 
 def show(self): 
    print("B Show") 
d = B() 
d.show() 
d.display()


#8.Explain Break, Continue and Pass Statement?
#break statement
#A break statement, when used inside the loop, will terminate the loop and exit. 
# If used inside nested loops, it will break out from the current loop

for i in range(10): 
 if i == 7:
    break 
print( i, end = ",")

#continue statement
#A continue statement will stop the current execution when used inside a loop, a
# nd the control will go back to the start of the loop
for i in range(10): 
 if i == 7:
    continue 
 print( i, end = ",")


#pass statement 
#pass statement is a null statement. When the Python interpreter comes across the pass statement, 
# it does nothing and is ignored
def my_func():
    print('pass inside function')
pass
my_func()

#.9What are Python Iterators?
iter = iter(['A', 'B', 'C'])
print(next(iter))
print(next(iter))
print(next(iter))


#10.What does *args and **kwargs mean? Expain?
#*args
def ar(*a):
    print(sum(a))
ar(1, 2, 3, 4, 5)

#**kwargs
def kw(**k):
    print(k)
kw(A=1,B=2,C=3)

#11.How Exception Handled In Python?
try:
    n=int(input("enter a no"))
    print("no is",n)
except:
    print("plz check ur input")
else:
    print("succsess")
finally:
    print("Thank you")


#12.What is ‘PIP’ In Python?
#Python pip is the package manager for Python packages. We can use pip to install packages that do not come with Python.?

#13.Where Python Is Used?
    1.#Web Applications
    2.#Desktop Applications
    3.#Database Applications
    4.#Networking Application
    5.#Machine Learning
    6.#Artificial Intelligence
    7.#Data Analysis
    8.#IOT Applications
    9.#Games and many more…!

#14.How to use F String and Format or Replacement Operator?
name="Naveen"
role="Python Developer"
print(f"Halo,My Name is {name} and im {role}")
print(("Hello My Name Is {} and i am {}").format(name,role))




#16.How to initialize Empty List, Tuple, Dict and Set?

    # Empty List:
    # a = []
    # Empty Tuple:
    # a = ()
    # Empty Dict:
    # a = {}
    # Empty Set:
    # a = set()

#17.Can You Concatenate Two Tuples. If Yes, How Is It Possible Since it is Immutable?
t1 = (1,2,3)
t2 = (7,9,10)
t1 = t1 + t2
print(t1)
#Output
(1, 2, 3, 7, 9, 10)


#18.How To Copy and Delete A Dictionary?

#19.Difference Between Anonymous and Lambda Function?

#Lambda is a small anonymous function in Python,
#that can accept any number of arguments, but can only have a single expression. 
#It is generally used in situations requiring an anonymous function for a short time period. 
#Lambda functions can be used in either of the two ways:

s = lambda x : x * x
s(5)
print(s(5)) #25
#Anonymous Function
print((lambda x: x*x)(5))


#20.How Class and Object Created in Python?
        # Python is an object oriented programming language.
        # Almost everything in Python is an object, with its properties and methods.
        # A Class is like an object constructor, or a "blueprint" for creating objects.

class MyClass:
 x = 5
obj = MyClass()
print(obj.x)    


#21.Difference Between Shallow Copy and Deep Copy?
#shallow copy 
list2 = [1,[2,3],4]
s_copy = list2.copy()
s_copy[1].append(1000)
print(list2)

#deep copy 
import copy
list1=[1,[2,3],4]
d_copy=copy.deepcopy(list1)
d_copy[1].append(5)
print(id(list1))
print((id(d_copy)))

#22 slicing 
str1 = "python life"
print(str1[:6])
print(str1[7:])

#23.#8 function with even numbers and odd numbers 
def number(i):
    if i%2==0:
        print(i,"is even")
    else:
        print(i,"is odd")
res=[number(i)for i in range(0,21)]

#24.list reverse and sort()
list1=[8,7,5,6,3,6,2,36]
list1.reverse()
print(list1)
list1.sort(reverse=True)
print(list1)

#25.list 1,2,3 high numbers
list1=[9000,9809,789987,9000,787]
list1.sort()
print(list1[-1])
print(list1[-2])
print(list1[-3])
#26.remove duplicate values 
number=[1,2,1,31,31,2,22,22,22,23,3]
remove=set(number)
print(remove)

#27used the split and remove numbers
import re 
text="cat4dog7tiger"
result=re.split("[0-9]",text)
print(result)

#28 remove all numbers in string 
import re 
text="b876890ir2345678d90876"
result=re.sub("[0-9]","",text)
print(result)


#29.multiplication 
t=10
for i in range(1,11):
    print(t,"x",i, "=",t*i)

#30 objects
class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def greet(self):
        print(f"Hello, my name is {self.name} and I am {self.age} years old.")
# Creating an object of the Person class
person = Person("John", 30)
# Accessing object attributes
print(person.name)  # Output: John
print(person.age)  # Output: 30

# Calling object method
person.greet()  # Output: Hello, my name is John and I am 30 years old.


#31.dict increase values
d={1:10,2:20,3:30,4:40}
for i in d:
    d[i]=d[i]+1
print(d)

    

#.What is "Open" and "With" statement in Python?
#.How to use Map, Filter and Reduce Function in Python?
#.Explain Recursion by Reversing a List.?
#.How To Read Multiple Values From Single Input?



#1.What is Python?
        # Python is a high-level, interpreted programming language known for its simplicity and readability.
        # It has a design philosophy that emphasizes code readability, making it easier to write and understand.

#2.What are the key features of Python?
        # Some key features of Python are:
        # Simple and easy-to-read syntax
        # Interpreted nature
        # Object-oriented programming (OOP) support
        # Dynamic typing
        # Automatic memory management (garbage collection)
        # Large standard library


#3.What is PEP 8?
        #PEP 8 is the official style guide for Python code. 
        #It provides guidelines and recommendations on how to write Python code to enhance its readability and maintainability. 
        #Adhering to PEP 8 is considered a best practice in the Python community.
        #PEP 8 provides guidelines and recommendations on how to format and structure Python code to enhance its readability and maintainability
        #PEP 8 covers various aspects of coding style, including naming conventions, code layout, indentation, comments, and documentation.  
        #developers can write code that is more readable and easier to understand for themselves and other programmers.
  

#4.What is the difference between a list and a tuple in Python?
        #Lists and tuples are both sequence types in Python, 
        #but the main difference is that lists are mutable (can be changed), 
        #whereas tuples are immutable (cannot be changed). 
        #You can modify, add, or remove elements from a list, but once a tuple is created, its elements cannot be modified.


#5.What is the difference between range() and xrange()?
        #In Python 2, range() returns a list of numbers in memory, 
        #while xrange() returns an xrange object that generates the numbers on-the-fly, 
        #which saves memory. In Python 3, range() behaves like xrange() in Python 2, generating numbers on-the-fly.

        #In Python 2.x, the range() function returns a list of numbers. 
        #To generate a sequence of numbers, you can use the xrange() function. The usage of xrange() is the same as range() in Python 3.x.


#6.What is a decorator in Python?
        #A Decorator is just a function that takes another function as an argument, 
        # add some kind of functionality and then returns another function. 
        #All of this without altering the source code of the original function that you passed in.


        #decorator is a design pattern in Python that allows a user to add new functionality
        #to an existing function or class without modifying its structure. 
        #It uses the @decorator syntax to apply the decorator to a function or class.


#7.What is the Global Interpreter Lock (GIL) in Python?
        #The Global Interpreter Lock (GIL) is a mechanism in CPython (the default 
        #implementation of Python) that allows only one thread to execute Python bytecode at 
        #a time. This means that even on a multi-core system, Python threads cannot run in 
        #parallel and cannot fully utilize multiple cores for CPU-bound tasks.


#8.What is the purpose of __init__() in Python classes?
        #The __init__() method is a special method (constructor) in Python classes that is 
        #automatically called when an object of the class is created. It is used to initialize the 
        #object's attributes or perform any other setup actions required for the object.




#32.write to upper case and all laters ?
list1=["Dhoni","Sachin","Virat"]
print(list1[0][1:4].upper())
for i in list1:
    print(i.upper())

#33.write to the first latter cap
list1=["naveen vempati","nani","divya"]
for i in list1:
    print(i[0].upper(),i[1:],sep="")

list1 = ["naveen vempati", "nani rocky", "divya"]
for i in list1:
    print(i.title())



#34.only positive numbers in list
list1 = [-90, -20, 30,70,-12, 4, 5]
for i in list1:
    if i > 0:
        print(i)



35.#prime numbers print for 50
# a prime number is a number that is only divisible by 1 and itself, with no other factors.
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) +1):
        if n % i == 0:
            return False
    return True
prime = list(filter(is_prime, range(2,50)))
print(prime)



36.#
a=[1,2,[3,4,[5,6,[7,8,[9,0]]]]]
b=0
c=len(a)
d=[]
while b<=c:
    [d.extend(x) if type(x) is list else d.append(x) for x in a]
    a=d
    d=[]
    b+=1
print(a)
#output
[1, 2, 3, 4, 5, 6, 7, 8, 9, 0]

#37.add multiple items in tuple
t=("Nani","Naveen","asdfgh","Kalyan")
t1=("Rocky","Rebel","Ram",)
t+=t1
print(t)

#38 remove tuple element
x=("Nani","Naveen","Naaaa")
y=list(x)
y.remove("Naveen")
x=tuple(y)
print(x)

#39.
import string 
new1=dict(zip(range(1,2)string.ascii_lowercase))
print(new1)

#40 print the enter the char and out put names to display 

d = {"ram": 100, "Naveen": 101, "Nani":1000, "sakshi": 200}
l = input("Enter A Char: ")
for key in d:
    if key[0] == l:
        print(key, d[key])


#41.print the enter the char and out put names to display 
l=["Nani","Naveen","Rocky"]
n=input("Enter A Latter : ")

for i in l:
    if i[0] == n:
        print(i,l.index(i))



42.#List
#Lists are used to store multiple items in a single variable.
#List items are ordered, changeable, and allow duplicate values.Support Index Valuse, mutable,


43.#tuple
#Tuples are used to store multiple items in a single variable.
#A tuple is a collection which is ordered and unchangeable.,immutable.support index values
#allow duplicate values.

44.#set
#Sets are used to store multiple items in a single variable.
#A set is a collection which is unordered, unchangeable*, and unindexed.Duplicates Not Allowed,immutable
#Note: Set items are unchangeable, but you can remove items and add new items.
#Sets cannot have two items with the same value.


45.#Dictionary
# Dictionaries are used to store data values in key:value pairs.
# A dictionary is a collection which is ordered*, changeable and do not allow duplicates.do not support index values 
# As of Python version 3.7, dictionaries are ordered. In Python 3.6 and earlier, dictionaries are unordered.



46.#what are the features added in latest version in python ?
# More Informative Error Tracebacks.
# Faster Code Execution.
# Nicer Syntax for Asynchronous Tasks.
# Improved Type Variables.
# Support for TOML Configuration Parsing.
# Other Pretty Cool Features. Faster Startup. Zero-Cost Exceptions. ...
# So, Should You Upgrade to Python 3.11?
# Conclusion.

47.#What is an Array?
#.Arrays are used to store multiple values in one single variable:
#An array, can be described as a "collection" or "sequence" of elements

48.#Does Python Support Multiple Inheritance. (Diamond Problem)
class A:
    def common(self):
        print("A")

class B(A):
    def common(self):
        print("B")

class C(A):
    def common(self):
        print("C")

class D(B, C):
    def common(self):
        print("D")
d = D()
d.common()

#49 compare to list1 and list2 true or false
list1 = [1, 2, 3, 4, 5, 6, 7, 8]
list2 = [8, 7, 6, 5, 4, 3, 2, 1]

cmp1 = (list1 == list2)  # False
cmp2 = (set(list1) == set(list2))  # True
print(cmp1)

list1 = [1, 2, 3, 4, 555, 6, 67]
list2 = [99, 98, 77]

if list1 == list2:
    print("The lists are equal.")
else:
    print("The lists are not equal.")

50 #tuple are compare 
t1 = (1, 2, 3, 4, 5, 6)
t2 = (6, 5, 4, 3, 2, 1)

if set(t1) == set(t2):
    print("The tuples contain the same elements.")
else:
    print("The tuples do not contain the same elements.")

51# sorted 
t1 = (1000,121,1212,1)
sort = sorted(t1)
print(sort)
#52 index valuse
t = (3, 1, 4, 1, 5, 9, 2, 6)
index = t.index(3)
print(index)




#opps consept programs 
class BankAccount:
    def __init__(self, accountNo, accountName, Ifsccode, balance):
        self.accountNo = accountNo
        self.accountName = accountName
        self.Ifsccode = Ifsccode
        self.balance = balance

    def display(self):
        print(self.accountNo, self.accountName, self.Ifsccode, self.balance)

object1 = BankAccount(20145616425, "Rocky", "SBINO00991", 500000)
object1.display()


#BANK ACCOUNT DETAILS WITH OPPS 
class BankAccount:
    def __init__(self,ACName, ACNumber,IFScode,Balance):
        self.ACName = ACName
        self.ACNumber = ACNumber
        self.IFScode = IFScode
        self.Balance = Balance
    def witdraw(self,ammount):
        self.Balance -=ammount
    def deposit(self,ammount):
        self.Balance += ammount
    def checkBalance(self):
        print(self.Balance)
ob = BankAccount("RockStar",20145616425,"SBIN09911",500000)
ob.checkBalance()
ob.deposit(50000)
ob.checkBalance()
ob.witdraw(120000)
ob.checkBalance()
ob.deposit(50000)
ob.checkBalance()

#multple inheritance
class Father:
    def method1(self):
        print("iam a father")
class Mother:
    def method2(self):
        print("iam a mother")
class Child(Father,Mother):
    def method3(self):
        print("Iam a childe")

Child1 = Child()
Child1.method3()
Child1.method2()
Child1.method1()

#patterns numbers
list1=[1,2,3,4,5]
for i in list1:
    a=str(i)
    b=i%10
    print(a*b)

list1 = [1, 2, 3, 4, 5]
for i in reversed(list1):
    a = str(i)
    b = i % 10
    print(a * b)


#calander and date
import datetime
print(datetime.date.today())
import calendar
calendar.prmonth(2022,2)

#print less 
d = {"Ram":500,"Naveen":600,"Nani":450,"Jany":300}

for i in d:
    if d[i]<500:
        print(i)

d = {"Ram": 500, "Naveen": 600, "Nani": 450, "Jany": 300}
for i in d:
    if i[0] == "N" or i[0] == "J":
        print(i, d[i])



#even numbers and odd numbers 
for i in range (1,10):
    if i % 2==0:
        print(i)
        
        
for i in range(1, 11):
    if i % 2 != 0:
        print(i)





#oops These are the fundamental concepts of Object-Oriented Programming (OOP) in Python.
(1)#class Class is a blueprint which defines some properties and behaviors.
#1.in python every thing is an object.
#2.to create objects we required some model or plan or blueprint wich is nothing but a class
#3.class can be a container for propertys and methods 
#4.propertys can reprasented by variables
#5.actions can reprasented by methods 

(2)#what is objects 
#1 pysical extence of a class is an objects 
#2 we can create a any number of objects for a class.

(3)#Inheritance
#1Inheritance allows a class (subclass) to inherit attributes and methods from another class (superclass). 
#2The subclass can extend or modify the inherited behavior and also add its own unique attributes and methods.

(4)#Polymorphism
#polymorpisum in interface multiple methods
#Polymorphism can be achieved through method overriding and method overloading.
#allow to write a multiple methods with the same name
#by changing the no parameters
#by changing the type of  parameters 

(5)#Abstraction
#Hiding internal implementation details, providing essential features to the user.
(6)#Encapsulation
#Bundling data and methods into a class, providing data hiding and protection.
#Encapsulation provides data hiding and protects the internal state of an object from direct external access.



#A for loop is used for iterating over a sequence (that is either a list, a tuple, a dictionary, a set, or a string).
#This is less like the for keyword in other programming languages, 
# and works more like an iterator method as found in other object-orientated programming languages.


# Intel, IBM, , Facebook, JP Morgan Chase, 
#Spotify, and a number of other massive companies. It's one of the four main languages at Google,
# Python is used by Google's YouTube  Pinterest, and Instagram. NASA,Netflix  nis largely written in Python. Same with Reddit, 

# remove to string duplicates value  
x = "naveen"
y=set(x)
print(y)

x = input("Enter a string: ")
y = "".join(set(x))
print(y)



# 1. What is the definition of the class and Object?
# 2. What is Encapsulation
# 3. What is Inheritance
# 4. Advantage of Inheritance
# 5. Types of Inheritance
# 6. What is Method overloading
# 7. What is the Method overriding
# 8. What is Polymorphism
# 9. Why do we call Python is Dynamically typed language
# 10. Define Namespace in Python
# 11. Scope resolution in Python
# 12. What is the Python path
# 13. How do you split function in Python
# 14. What is the Difference between end and sep parameters?
# 15. What is a list?
# 16. Methods of list?
# 17. What is a tuple?
# 18. WAP to remove duplicates in a string?

